public class Test {
    public static void main(String[] args) {
        MobilePhone p1 = new MobilePhone("HUAWEIMate30","16945678999",3380);
        p1.display();

    }


}

public class MobilePhone {

    private String Brand;
    private String Num;
    private int Price;

    public MobilePhone(String Brand,String Num,int Price){
        this.Brand = Brand;
        this.Num = Num;
        this.Price = Price;
    }

    public void display(){
        System.out.println("brand:"+Brand);
        System.out.println("TelePhoneNum:"+Num);
        System.out.println("price:"+Price);
    }


}

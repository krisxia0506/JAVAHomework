public class Worker {
    private String Name;
    private int Age;
    private double Salary;
    private String Level;
    //空构造方法
    public  Worker(){}
    //3形参构造方法
    public Worker(String Name,int Age,double Salary,String Level){
        this.Name = Name;
        this.Age = Age;
        this.Salary = Salary;
        this.Level = Level;
    }
    //置取方法

    //name
    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    //age
    public int getAge() {
        return Age;
    }

    public void setAge(int age) {
        Age = age;
    }

    //salary
    public double getSalary() {
        return Salary;
    }

    public void setSalary(double salary) {
        Salary = salary;
    }

    //level
    public String getLevel() {
        return Level;
    }

    public void setLevel(String level) {
        Level = level;
    }

    public void display(){
        System.out.println("name="+Name);
        System.out.println("age="+Age);
        System.out.println("salary="+Salary);
        System.out.println("level="+Level);
    }
}
